package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"example.com/dau/internal/date"
	"example.com/dau/internal/dau"
)

type HTTPServer struct {
	service *dau.Service
}

func (s *HTTPServer) Event(c *gin.Context) {
	var request dau.EventRequest
	if err := json.NewDecoder(c.Request.Body).Decode(&request); err != nil {
		c.AbortWithError(http.StatusBadRequest, err)
		return
	}

	if err := s.service.Event(c, &request); err != nil {
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	c.Status(http.StatusOK)
}

func (s *HTTPServer) Dau(c *gin.Context) {
	rawList := c.QueryArray("authors_list")
	var authorsList []int
	for _, rawID := range rawList {
		id, err := strconv.Atoi(rawID)
		if err != nil {
			c.AbortWithError(http.StatusBadRequest, err)
			return
		}
		authorsList = append(authorsList, id)
	}

	result, err := s.service.Dau(c, authorsList)
	if err != nil {
		c.AbortWithError(http.StatusInternalServerError, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func NewServer(port int) *http.Server {
	httpServer := &HTTPServer{service: dau.NewService(date.NewService())}

	gin.SetMode(gin.ReleaseMode)
	handler := gin.Default()
	handler.POST("/event", httpServer.Event)
	handler.GET("/dau", httpServer.Dau)

	return &http.Server{
		Handler: handler,
		Addr:    fmt.Sprintf(":%d", port),
	}
}
