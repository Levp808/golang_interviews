package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
)

var (
	port int
)

func init() {
	flag.IntVar(&port, "port", 8080, "server port")
	flag.Parse()
}

func main() {
	server := NewServer(port)

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, os.Kill)
	defer cancel()

	serverDone := make(chan struct{})
	go func() {
		defer close(serverDone)
		if err := server.ListenAndServe(); err != nil {
			log.Printf("server done: %s", err.Error())
		}
	}()

	go func() {
		<-ctx.Done()
		server.Shutdown(context.Background())
	}()

	<-serverDone
}
