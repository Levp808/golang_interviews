package dau

import (
	"context"

	"example.com/dau/internal/date"
)

type Service struct {
	date date.Service
}

type EventRequest struct {
	UserID   int `json:"user_id"`
	AuthorID int `json:"author_id"`
}

func (s *Service) Event(ctx context.Context, request *EventRequest) error {
	// TODO: implement me
	return nil
}

func (s *Service) Dau(ctx context.Context, authorsList []int) (uniqueUsersCount []int, err error) {
	// TODO: implement me
	return nil, nil
}

func NewService(date date.Service) *Service {
	return &Service{date: date}
}
